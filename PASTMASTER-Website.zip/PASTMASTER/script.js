// Demo paper data. Replace each pdf value with the path to your real PDF file.
const papers = [
  { title: "Mathematics Past Paper", subject: "Mathematics", grade: "11", type: "Past Paper", year: "2024", language: "English Medium", pdf: "pdfs/grade-11-maths-2024.pdf" },
  { title: "Science Model Paper", subject: "Science", grade: "11", type: "Model Paper", year: "2025", language: "English Medium", pdf: "pdfs/grade-11-science-model-2025.pdf" },
  { title: "English Past Paper", subject: "English", grade: "10", type: "Past Paper", year: "2023", language: "English Medium", pdf: "pdfs/grade-10-english-2023.pdf" },
  { title: "History Marking Scheme", subject: "History", grade: "OL", type: "Marking Scheme", year: "2024", language: "Sinhala Medium", pdf: "pdfs/ol-history-marking-2024.pdf" },
  { title: "Biology Past Paper", subject: "Biology", grade: "AL", type: "Past Paper", year: "2022", language: "English Medium", pdf: "pdfs/al-biology-2022.pdf" },
  { title: "ICT Model Paper", subject: "ICT", grade: "AL", type: "Model Paper", year: "2025", language: "English Medium", pdf: "pdfs/al-ict-model-2025.pdf" }
];

const paperGrid = document.getElementById("paperGrid");
const searchInput = document.getElementById("searchInput");
const gradeFilter = document.getElementById("gradeFilter");
const typeFilter = document.getElementById("typeFilter");
const paperCount = document.getElementById("paperCount");
const emptyState = document.getElementById("emptyState");

function renderPapers() {
  const search = searchInput.value.trim().toLowerCase();
  const grade = gradeFilter.value;
  const type = typeFilter.value;

  const filtered = papers.filter(paper => {
    const matchesSearch = `${paper.title} ${paper.subject} ${paper.grade} ${paper.year}`.toLowerCase().includes(search);
    const matchesGrade = grade === "all" || paper.grade === grade;
    const matchesType = type === "all" || paper.type === type;
    return matchesSearch && matchesGrade && matchesType;
  });

  paperGrid.innerHTML = filtered.map(paper => `
    <article class="paper-card">
      <div class="paper-card-top">
        <span class="paper-type">${paper.type}</span>
        <span class="paper-year">${paper.year}</span>
      </div>
      <h3>${paper.title}</h3>
      <p>${paper.subject} learning resource for ${paper.grade === "AL" ? "Advanced Level" : paper.grade === "OL" ? "Ordinary Level" : "Grade " + paper.grade} students.</p>
      <div class="paper-meta">
        <span>▣ ${paper.grade === "AL" || paper.grade === "OL" ? paper.grade : "Grade " + paper.grade}</span>
        <span>◉ ${paper.language}</span>
      </div>
      <div class="paper-actions">
        <a class="preview-btn" href="${paper.pdf}" target="_blank" rel="noopener">Preview ↗</a>
        <a class="download-btn" href="${paper.pdf}" download>Download ↓</a>
      </div>
    </article>
  `).join("");

  paperCount.textContent = `${filtered.length} resource${filtered.length === 1 ? "" : "s"}`;
  emptyState.hidden = filtered.length !== 0;
}

[searchInput, gradeFilter, typeFilter].forEach(element => {
  element.addEventListener("input", renderPapers);
  element.addEventListener("change", renderPapers);
});

document.querySelectorAll(".grade-card").forEach(card => {
  card.addEventListener("click", () => {
    gradeFilter.value = card.dataset.grade;
    renderPapers();
    document.getElementById("papers").scrollIntoView({ behavior: "smooth" });
  });
});

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("mainNav").classList.toggle("open");
});

document.querySelectorAll("#mainNav a").forEach(link => {
  link.addEventListener("click", () => document.getElementById("mainNav").classList.remove("open"));
});

document.getElementById("year").textContent = new Date().getFullYear();
renderPapers();
